# TP2 WebGL 
## Courbes de Bézier en WebGL

#### Réalisé par Quentin LOURENCO, Amaury GIOT, Antonin VEROONE et Nicolas BARRAT, CIR3