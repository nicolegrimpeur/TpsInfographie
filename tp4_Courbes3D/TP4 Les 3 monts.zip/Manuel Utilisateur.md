# Manuel d'utilisateur

1) Ouvrez le site en double-cliquant sur le fichier index.html
   1) Si aucune application n'est associé, choisissez votre navigateur par défaut
   

2) Sur la page, vous avez plusieurs possibilités :
   1) Vous pouvez zoomer / dézoomer avec la molette de la souris

   2) Vous pouvez déplacer la caméra autour de la clé à molette

3) Si la map ne s'affiche pas, faites jouer la caméra avec la molette ou en essayant de vous déplacer, celle ci apparaitra automatiquement