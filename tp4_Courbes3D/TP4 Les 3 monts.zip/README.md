# TP4 WebGL 
## Courbes 3D en WebGL et application

#### Réalisé par Quentin LOURENCO, Amaury GIOT, Antonin VEROONE et Nicolas BARRAT, CIR3