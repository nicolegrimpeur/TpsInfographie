# TP1 Hello WebGl

#### Quentin LOURENCO, Amaury GIOT et Nicolas BARRAT

Le main.js contient toutes les fonctions liées au canva 

Le index.html est divisé en deux parties :
- Une première partie avec le code html de la partie permettant d'afficher la courbe que l'on souhaite
- Une deuxième partie avec l'ajout des événements sur le bouton et le select de préselection 

Pour lancer la page, il suffit de double clicker sur le index.html dans votre explorateur de fichiers