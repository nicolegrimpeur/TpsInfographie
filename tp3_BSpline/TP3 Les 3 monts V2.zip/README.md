# TP3 WebGL 
## Courbes B-splines en WebGL

#### Réalisé par Quentin LOURENCO, Amaury GIOT, Antonin VEROONE et Nicolas BARRAT, CIR3
